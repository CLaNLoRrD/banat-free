public class UserRegistrationM {
    public string email {get; set;}
    public string LastName {get; set;}
}