var builder = WebApplication.CreateBuilder(args);
//builder.Services.addcontrollers();
var app = builder.Build();




//app.MapControlllers();
app.UseStaticFiles();
app.MapGet("/", () => "Hello World!");

app.Run();
