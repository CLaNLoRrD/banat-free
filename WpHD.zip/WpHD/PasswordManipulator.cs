class PasswordManipulate {
    public static string GeneratorHash(){

    }

    public static string CalculateHash (string email,string salt){
        var sha = SHA256.Create();

        string tohash = email + salt;
        byte[] tohashbytearray = tohashbytearray; 
        byte[] result = sha.ComputeHash(dataArray);
    }
}