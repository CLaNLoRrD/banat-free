public class DataBaseCollector {
static void RegisterUser (string email, string password){


}
static bool VerifyUser(string email, string password){
    return false;
    
}

}