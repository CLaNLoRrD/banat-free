


create table 'user' {

"UserID" Primary KEY NOT NULL
    "Email".text  UNIQUE NOT NULL
    "PasswordHash". text NOT NULL
    "PasswordSalt". text NOT NULL
};